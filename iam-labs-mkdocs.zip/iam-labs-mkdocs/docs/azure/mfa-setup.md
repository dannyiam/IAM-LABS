# Azure AD MFA Setup Lab

Step-by-step guide to enabling MFA for a test user in Azure AD.
