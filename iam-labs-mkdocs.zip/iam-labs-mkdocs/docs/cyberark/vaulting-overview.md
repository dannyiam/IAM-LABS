# CyberArk Vaulting Overview

Basics of vaulting credentials in CyberArk.
