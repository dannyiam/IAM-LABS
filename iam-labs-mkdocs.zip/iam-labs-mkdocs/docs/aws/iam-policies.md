# AWS IAM Policies Lab

Guide to creating and comparing managed vs inline IAM policies.
